class CreateTenantPage{


    static clickGetStarted(name) {

        cy.get('[id="username"]').type(name)
    }


    static getPassword(password) {

        cy.get('[id="password"]').type(password)
    }
}

export default CreateTenantPage;