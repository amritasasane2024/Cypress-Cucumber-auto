import {Given, When, Then, And} from "@badeball/cypress-cucumber-preprocessor";
import CreateTenantPage from "./createTenantPage";


Given("I am logged into Arcware application", () => {

    cy.contains("Get started").should("be.visible");

})

When("I click on 'Get Started' link",  ()  => {   
  
     
    cy.get('[title="Get started"]').click();
  
})

Then("I should be displayed with different plans", () => {
    
    cy.contains("Select plans to get started").should("be.visible");
})