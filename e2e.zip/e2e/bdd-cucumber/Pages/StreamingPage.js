import { attach } from "@badeball/cypress-cucumber-preprocessor";

class StreamingPage{
    


  checkStreaming() {

    cy.wait(15000);
    cy.get('[id="streamingVideo"]').then(($input) => {
        if ($input.length >0) {
          cy.log('Streaming displayed')
        } else {
            cy.log("Streaming not displayed")
        }
      })
  
} 


//this will check with the video property

checkStreamingVideo() {


//.get('video').contains("Start connection to stream signalling")

  if (cy.get('[id="playerUI"]').find('[id="letters-wrapper"]'))
  {
  cy.contains('Signalling connection established').should('be.visible' , {timeout : 4000})
  cy.log("Stream loading" )
 // cy.wait(4000)
  }

  cy.log("Video about to stream")
  cy.wait(15000)


  cy.get('video').invoke('prop', 'autoplay', 'true', {timeout : 10000})
  let timex
  cy.get('video').should('have.prop', 'currentTime').then((timex) => {

  cy.log('Time captured is expected to be greater than 0 for streaming')
  cy.log ("Time captured: " +timex)
  attach ("Time captured: " +timex)
  expect(timex).to.be.greaterThan(0);
    //return timex

  });


  cy.get('video').should('not.have.value', ["Click To Restart", "Ticket destroyed"])  
  cy.get('video').should('not.have.value', "Disconnected: Websocket disconnect (4450) - Forbidden. Reason: Unauthorized. ")


}


checkStreamingAPI() {

  cy.contains("Project ID").should('be.visible')

  let name 
  cy.get('[class="MuiTypography-root MuiTypography-caption css-958p72"]').then(($value) => {

  name = $value.text()
 // cy.log(name)
  return name

  }).then((name) => {

  var projIDArr = name.split('Project ID')
  return projIDArr

}).then((projIDArr) => {
  cy.log (projIDArr[1])
  cy.request(Cypress.config('baseUrl')+ '/preview/v1/'+projIDArr[1])
  .its('status')
})
.should('eq' , 200);



if (cy.get('[id="playerUI"]').find('[id="letters-wrapper"]'))
{
  cy.contains('Signalling connection established').should('be.visible' , {timeout : 4000})
  cy.log("Stream loading" )
 // cy.wait(4000)
}


cy.get('video').should('not.have.value', ["Click To Restart", "Ticket destroyed"])  

}



//captures Framerate information for statistics
checkStreamParameters()

{

  // get more information
  cy.get('#statsIcon').click()
  cy.get('#statisticsResult').then(($value) =>{

  var Arr1 = ($value).text()

  //cy.log(Arr1)

  return Arr1

  }).then((Arr1) => {

  const statArr = Arr1.split('Framerate:')
  
  const statFrames = statArr[1].split('Frames')
  cy.log("Framerate captured is:" +statFrames[0])
  attach("Framerate captured is:" +statFrames[0])

   //return statArr[1]
  const statArr2 = statArr[0].split("Packets Lost:")
  const statPackets = statArr2[1].split('Video')
  cy.log("Packets Lost captured is:" +statPackets[0])
  attach("Packets Lost captured is:" +statPackets[0])
  //  cy.log(statPackets)
  })

}


checkLatencyParam()

{

  //cy.get('#statsIcon').click()
  cy.get('#ControlStats').find('#latencyTestHeader').contains("Latency Test")
  cy.get('#latencyTestHeader').find('input[type=button]').click({force:true})
  cy.wait(2000)
  cy.get('#latencyTestContainer').then(($value1) => {
    const latArr2 = $value1.text()
    //cy.log(latArr2)
    return latArr2
  
  }).then((latArr2) => {

    const statLatencyArr = latArr2.split('Net latency RTT (ms):')
    const latencyValue = statLatencyArr[1].split('UE Encode (ms):')
    cy.log("Latency captured is:" +latencyValue[0])
    attach("Latency captured is:" +latencyValue[0])
  })

}



}
export default StreamingPage;