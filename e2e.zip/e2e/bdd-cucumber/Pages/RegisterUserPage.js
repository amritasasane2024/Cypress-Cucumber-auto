class RegisterUserPage{

     visit(Url) {

        cy.visit(Url);

    }


     enterEmail(name) {

        cy.get('[id="username"]').type(name)
    }


     enterPassword(password) {

        cy.get('[id="password"]').type(password)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
    }


     clickCreateUser() {

        //Clicks 'Create Account' link
        cy.get('[id="registration-link"]').click();
    
    }


     getRegisterPage() {

        //Verifies Titles, Labels 
        cy.contains("Register").should("be.visible");
        cy.contains("Create an account in Arcware Cloud").should("be.visible");
    }


     getRegisterPageLinks() {

        //Verifies Titles, Links 
        cy.contains("Register").should("be.visible");
       // cy.get('[type="submit"]').click();
        cy.contains("Already have an account?").should("be.visible");
       // cy.contains("Log in").should("be.visible");
       // cy.get('[id="login-link"]').click();
    }
    

     getAddInfo() {

        //Verifies Additional Information section
        cy.contains("Additional Information").should("be.visible");
    }


     clickBasicFields() {

        //Checks all the present fields
        cy.get('[id="firstName"]').click();
        cy.get('[id="lastName"]').click();
        cy.get('[id="email"]').click();
        cy.get('[id="password"]').click();
        cy.get('[id="password-confirm"]').click({force:true});
    
    }


     clickAdditionalFields() {

        //Checks all the present fields
        cy.get('[id="industry"]').should("be.not.have.value");
        cy.get('[id="company"]').click({force:true});
        cy.get('[id="companySize"]').should("be.not.have.value");
        cy.get('[id="jobTitle"]').click();
        cy.get('[id="countryCode"]').should("be.not.have.value");
        cy.get('[id="city"]').click();
        cy.get('[id="findUs"]').should("be.not.have.value");
        cy.get('[id="phone"]').click();
            
    }


     enterBasicFields(firstName, lastName, email, password, confPassword) {

        //Enters input for all the present fields
        cy.get('[id="firstName"]').type(firstName);
        cy.get('[id="lastName"]').type(lastName);
        cy.get('[id="email"]').type(email);
        cy.get('[id="password"]').type(password);
        cy.get('[name="password-confirm"]').click({force:true}).type(confPassword);
    
    }


     enterAdditionalFields(industry, company, companySize, job, countryCode, city, findUs, phone ) {

        //Enters input for all the present fields
        cy.get('[id="industry"]').select(industry);
        cy.get('[id="company"]').click({force:true}).type(company);
        cy.get('[id="companySize"]').select(companySize);
        cy.get('[id="jobTitle"]').type(job);
        cy.get('[id="countryCode"]').select(countryCode);
        cy.get('[id="city"]').type(city);
        cy.get('[id="findUs"]').select(findUs);
        cy.get('[id="phone"]').type(phone);
    
    }


     clickCheckBoxes() {

        //Checks all the present fields
        //cy.get('[role="presentation"]').click({force:true});

        cy.get('iframe').first().its('0.contentDocument.body').should('not.be.undefined').and('not.be.empty')
        .then(cy.wrap).find('#recaptcha-anchor').should('be.visible').click(); //Captcha
        cy.wait(10000);
        cy.get('[id="user.attributes.acceptTerms"]').click({force:true});
                    
    }

    
    clickRegister() {

      cy.get('[type="submit"]').click();
  }


      checkTermsCond() {

      //cy.get('[id="user.attributes.acceptTerms"]').click();
      //get('[value="true"]').click();

}


   getRegisterConfirmation() {

      cy.contains("verify your email address").should("be.visible");
}
}





export default RegisterUserPage;