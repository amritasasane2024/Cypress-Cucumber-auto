//import { removeData } from "cypress/types/jquery";

class UploadPackagePage{


 

      
    
    clickBrosweOption() {

       // cy.contains("browse your package").should("be.visible").click({force:true});
        cy.get('[class="MuiBox-root css-k787m0"]').find('[class="MuiTypography-root MuiTypography-body2 css-1f0zetj"]').should('have.text',"Drag + dropor browse your package").click({force:true});

}
   
    checkPackagesPage() {

    cy.contains("List of uploaded packages").should("be.visible").click();

}

    selectPackage(upFile) {

       // cy.selectFile(fileUp);
     //   cy.get('.MuiTableBody-root css-1jsedeq').attachFile(filepath);
      
     //const filePath = 'img3.zip'
    // cy.get('[class="MuiBox-root css-k787m0"]').find('[class="MuiTypography-root MuiTypography-body2 css-1f0zetj"]').should('have.text',"Drag + dropor browse your package").attachFile(filePath);
   
    cy.get('input[type=file]').click({force:true}).selectFile('cypress/fixtures/'+upFile, {force:true})
   
   
   // cy.get('input[type=file]').click({force:true}).attachFile(upFile)
    //.invoke(removeData , 'display: none;')
    
    
    cy.wait(20000)
     //   cy.readFile('cypress\\SmallTestFile');

}

    checkTenantInfo() {

        cy.contains("Tenant details").should("be.visible");
       
}


    checkTenantAndPlan() {

        cy.contains("Tenant details").should("be.visible");
        cy.contains("Currently you are starting your Trial. Your trial includes:").should("be.visible");
        
   

}


    clickReleaseButton() {

     //   cy.get('[data-testid="RocketLaunchIcon"]').should("be.visible").click();
       // cy.get('button[id=":r16:"]').find('[data-testid="RocketLaunchIcon"]').click();
        cy.get('button[tabindex="0"]').find('svg[data-testid="RocketLaunchIcon"]').click();
        
}
    
    clickConfirmRelease() {

      
          cy.get('[type="button"]').contains("Confirm").click();
}
   
    checkReleaseStatus() {

      //  cy.wait(10000);
        cy.contains("Releasing").should("be.visible");
      
}

    checkRelevantStatus() {

        cy.get('[class="MuiTypography-root MuiTypography-body2 css-1nywgq6"]').should('not.have.value',"Active");
        cy.wait(20000);
        // cy.get('[class="MuiTypography-root MuiTypography-body2 css-1nywgq6"]').should('have.value',"Rolling out");
        //cy.contains("Rolling out").should("be.visible");
   
        cy.get('[class="MuiTypography-root MuiTypography-body2 css-1nywgq6"]').should('not.have.value',"Releasing");
   // cy.wait(10000);
}


    checkFinalStatus() {

        //      cy.wait(15000);
        //cy.contains("Active").should("be.visible");
       cy.get('[class="MuiTypography-root MuiTypography-body2 css-1nywgq6"]').should('not.have.value',"Active");
       
       cy.wait(20000);
     //   cy.get('[class="MuiTypography-root MuiTypography-body2 css-1nywgq6"]').should('have.value','Active');
       cy.get('[class="MuiTypography-root MuiTypography-body2 css-1nywgq6"]').contains("Active").should("be.visible");
       
        
}

    checkAutoReleaseOption() {

      
        cy.get('[class="MuiCardContent-root css-7bjnhx"]').contains("Auto-release").should("be.visible");
      //  cy.get('[class="MuiCardContent-root css-7bjnhx"]').find('[type="checkbox"][name="autoRelease"]').should('be.visible');
}


    clickAutoReleaseButton() {

      
    cy.get('[class="MuiCardContent-root css-7bjnhx"]').find('[type="checkbox"][name="autoRelease"]').click();
   
}

    checkAutoReleaseButtonMsg() {

      
    cy.get('#notistack-snackbar').contains("Project was updated successfully").should('be.visible');
    cy.wait(4000);
    cy.get('[class="MuiCardContent-root css-7bjnhx"]').find('[type="checkbox"][name="autoRelease"]').click();
    cy.get('#notistack-snackbar').contains("Project was updated successfully").should('be.visible');
    cy.wait(4000);
}


}

export default UploadPackagePage;