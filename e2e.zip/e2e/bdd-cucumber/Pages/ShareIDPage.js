//import { error } from "cypress/types/jquery";
//import { Runnable } from "mocha";

class ShareIDPage{
    



     clickCreateShareIDLink() {

        cy.get('[class="MuiTypography-root MuiTypography-h5 css-h9d2wg"]').contains(" Create New Share ID").click();
    
    }

     enterShareIDDetails(projName,shareID) {

        cy.get('#user').type(shareID);
        cy.get('#demo-multiple-checkbox').click().get('[class="MuiButtonBase-root MuiMenuItem-root MuiMenuItem-gutters MuiMenuItem-root MuiMenuItem-gutters css-10047ey"]').contains(projName).click({force:true}); 
      
     }


     submitShareID() {

     cy.get('[type="submit"]').contains("Create new share ID").click({force:true});

    }

     checkCreatedShareID(shareID) {

       cy.get('[class="MuiTypography-root MuiTypography-h6 css-1dwmdut"]').contains(shareID);

    }


     checkListShareIds(shareID) {

        cy.get('[class="MuiGrid-root MuiGrid-container css-1tln94c"]').contains(shareID);

    }


     checkShareIdDetails(shareID) {

        cy.get('[class="MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation1 MuiCard-root css-1nx5z5j"]').contains(shareID);
        cy.get('[class="MuiTypography-root MuiTypography-caption css-1wzbnv1"]').contains("share-");
        cy.get('[class="MuiBox-root css-15793mx"]').contains("Active");
        cy.get('[class="MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation1 MuiCard-root css-1nx5z5j"]').contains("Copy Share Link");
        cy.get('[class="MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation1 MuiCard-root css-1nx5z5j"]').contains("Created at");
        cy.get('[class="MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation1 MuiCard-root css-1nx5z5j"]').contains("Start date/ time");
        cy.get('[class="MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation1 MuiCard-root css-1nx5z5j"]').contains("End date/ time");
        cy.get('[class="MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation1 MuiCard-root css-1nx5z5j"]').contains("Remaining time");
             

    }   



     checkCopyLink() {

        cy.get('[class="MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation1 MuiCard-root css-1nx5z5j"]').contains("Copy Share Link");

    }



     clickCopyLink() {

        cy.get('[class="MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation1 MuiCard-root css-1nx5z5j"]').contains("Copy Share Link").click();

    }

     clickPasteLink() {

       cy.window().its('navigator.clipboard').invoke('readText');
      // cy.log(msg);
    }



     checkCopiedMsg() {

    
    //    cy.contains("Link to dedicated stream page 'https://share.stormblast.arcware.cloud/'+'shareIDGen' was copied to clipboard!") .should('be.visible');
        cy.contains("was copied to clipboard!");
    }



    // extract latest share id from the list of avaiable, append it to the shared link url
     getGeneratedShareID(envUrl) {

        let getText;
        let myShareid;
       
              cy.get('[class="MuiStack-root css-1tw5gxz"]').then(($value) => {
              return getText = $value.text()
           
        
        })
            .then((getText) => {
             var splitshare = getText.split("share-")
            return splitshare 
          
          })
          
          .then((splitshare) => {

            myShareid = 'share-'+splitshare[1]
            return myShareid
          })  
          .then((myShareid) => {

            
            cy.visit('https://share.' + envUrl +'/v1/'+ myShareid)    
            
            //  return cy.wrap(myShareid)
            
          
          })
      
  
   
    }

    getGeneratedShareID2() {

      let getText;
      let myShareid;
     // cy.get('[class="MuiTypography-root MuiTypography-caption css-1wzbnv1"]').then(($value) => {
        return     cy.get('[class="MuiStack-root css-1tw5gxz"]').then(($value) => {
            return  $value.text()
          //getText =  cy.get('[class="MuiStack-root css-1tw5gxz"]');
          
       //   cy.log("Share ID is....", getText)
      })
          .then((getText) => {
      //      cy.log("Share ID is....", getText)
          
          //var splitshare = getText.split("share-").then(() => {
         return getText.split("share-")
     //     cy.log("Final share id is.." , splitshare)
        
        
        })
        
        .then((splitshare) => {

      //    myShareid = 'share-'+splitshare[1]
          return ('share-'+splitshare[1])
      //  cy.log('share-'+splitshare[1])
        // cy.log("My final share id extracted is::" ,myShareid );
          
        })

        
     //   return cy.then(()  => {

//          cy.log(myShareid)
       
       // cy.log("Completed") 
       /* 
        .then((myShareid) => {

          //cy.log("My first share id is::" , splitshare[0]);
          //cy.log("My second share id is::" , splitshare[1]);
       
          //cy.log("My final share id extracted is::" ,myShareid );
          
          cy.visit('https://share.stormblast.arcware.cloud/v1/'+myShareid)    
          // catch 'XR' exception
          //  return cy.wrap(myShareid)
          
        
        })
    */
      //  cy.log("Completed") 
      //  return cy.wrap(myShareid)
 
  }


      getGeneratedShareID1() {

   //     cy.get('[class="MuiStack-root css-1tw5gxz"]').invoke('text').then((text) => {
            cy.get('[class="MuiStack-root css-1tw5gxz"]').invoke('text').then((text) => {

            cy.log('text',text).then(() => {

             return cy.wrap(text)
            //.split("share-");

        })
        
        }) 
      //  .should('equal', 'share')

    }


     createShareIDlink(myShareid) {

        cy.log("share id is:" ,myShareid);

        var shareLink = 'https://share.stormblast.arcware.cloud/v1/'+myShareid ;
        cy.log("Final shareid link for browser is::",shareLink);

    }



}
export default ShareIDPage;