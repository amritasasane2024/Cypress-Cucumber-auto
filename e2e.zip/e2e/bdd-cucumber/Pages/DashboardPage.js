//import { escape } from "cypress/types/lodash";

class DashboardPage

{
     checkProjects() {

        cy.contains("Projects").should("be.visible");
    

}

     clickProjectsTab() {

   //     cy.get('[class="MuiTypography-root MuiTypography-h4 css-1vt5em4"]').contains("New Notifications").type('{esc}')  

        cy.get('[class="MuiBox-root css-17ls7xt"]').contains("Projects").should("be.visible").click({force:true});
   

}

     checkProjectList(projName) {


  //  cy.get('[class="MuiTypography-root MuiTypography-h4 css-1vt5em4"]').contains("New Notifications").type('{esc}')
    
    cy.get('[class="MuiButtonBase-root MuiCardActionArea-root css-f353yp"]').contains(projName).should("be.visible");
     
 

}
     /*checkProjectsPage(projName) {

        cy.get('[class="MuiBreadcrumbs-li"]').contains("Projects").should("be.visible").click({force:true});
      //  cy.contains(projName).should("be.visible");
      cy.get('[class="MuiBox-root css-lucjwf"]').click({force:true});
      cy.wait(2000);

}
*/
     checkOrganizationTab() {

          cy.get('[class="simplebar-mask"]').contains("Organization").should("be.visible");
   

}
     
     clickOrganizationTab() {

          cy.get('a[href="/organization"]').click();
   
}
   
     checkAddOnsTab() {
          cy.get('[class="simplebar-mask"]').contains("Add-ons").should("be.visible");
   
}

     clickAddOnsTab() {

          cy.get('[class="simplebar-mask"]').contains("Add-ons").should("be.visible").click({forcd:true});

}

}

export default DashboardPage;
