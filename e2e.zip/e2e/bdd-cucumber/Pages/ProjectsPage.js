class ProjectsPage{


 checkPreviewTab() {

  cy.get('[class="MuiButtonBase-root MuiCardActionArea-root css-y8tkid"]').find('[data-testid="OndemandVideoIcon"]').should('be.visible');
  //.contains('text', "Preview");

}

 clickPreviewTab() {

  cy.get('[class="MuiTypography-root MuiTypography-h5 css-1iavygf"]').contains("Preview").should("be.visible").click();

}

 checkPackagesTab() {

  cy.contains("Packages").should("be.visible");

}

 clickPackagesTab() {

  cy.contains("Packages").should("be.visible").click();

}


 checkShareIDTab() {

   
//  cy.contains("Share ID").should("be.visible");
  cy.get('a[href="/share-id"]').should('be.visible')
 
}

 clickShareIDTab() {

 //   cy.contains("Share ID").should("be.visible").click();
    cy.get('a[tabindex="0"][href="/share-id"]').should('be.visible').click()
}

 checkShareIDPage() {

    cy.contains("Share ID Management").should("be.visible").click();

}

 checkSettingsTab() {

//  cy.get('a[tabindex="0"]').contains("Settings").should("be.visible");
    cy.get('[data-testid="SettingsIcon"]').should('be.visible');
}


 clickSettingsTab() {
  
  cy.contains("Settings").should("be.visible").click({force:true});

}

closeSettingsMsg()

{


  cy.get('.MuiStack-root.css-11zh7gr').should('be.visible').click({force:true});
  
  //find('[p.MuiTypography-root.MuiTypography-body2.css-1ua5i5i]').should('be.visible');

//  cy.get('[.MuiStack-root.css-11zh7gr]').find('[data-testid="CloseIcon"]')
/*cy.get('[.MuiStack-root.css-11zh7gr]').contains("Dismiss").then((title) => {

  expect(title).to.be.visible.click() ;

})
*/
}

 navigateProject(projName) {

//    cy.get('h6[class="MuiTypography-root MuiTypography-h6 css-ua511f"]').should('contain.text',projName).click();
    cy.contains(projName).click();
    
    cy.log("Project found");

}

 navigateProject2(projName) {

    cy.get('h6[class="MuiTypography-root MuiTypography-h6 css-ua511f"]').should('contain.text',projName).click();
    
    cy.log("Project found");

}

 selectProject(projName) {

  cy.get('[class="MuiButtonBase-root MuiCardActionArea-root css-f353yp"]').contains(projName).should("be.visible").click({force:true});

  cy.log("Project found");


}

 checkProjectDetails(projName) {

  cy.get('li[class="MuiBreadcrumbs-li"]').contains(projName).should("be.visible");
    

}


checkProjectsPage() {

  //cy.get('[aria-label="Go to project details"]').should("be.visible");
 

}


checkProjectPlanTab() {

    cy.contains("Project plan").should("be.visible").click();
  }


  clickProjectPlanTab() {
  
    cy.contains("Project plan").should("be.visible").click();
  
  }
  
  checkProjectPlanDetails(projName) {

    cy.contains(projName).should("be.visible");
    cy.contains("Current plan:").should("be.visible");
    cy.get('[class="MuiStack-root css-1c3sth5"]').contains("Core Plan").should("be.visible").click({force:true});
    cy.contains("Your current plan includes").should("be.visible");
      
  }


  clickNewProjectLink() {
  
    cy.contains("Create a new project").should("be.visible").click();
  
  }


  enterProjectInfo() {

    cy.contains("Create a new project").should('be.visible');
    cy.get('[name="name"][type="text"]').type("Test");
    
  }

  clickCreateProjectButton() {
  
    cy.get('[type="submit"]').contains("Create project").click();
  
  }

  checkCreatedMsg() {

    cy.get('#notistack-snackbar').contains("Template was successfully added").should('be.visible');
    
  }
}

export default ProjectsPage;