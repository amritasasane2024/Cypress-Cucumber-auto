
class OrganizationPage {



   checkOrganizationPage() {

      //   cy.contains("Organization").should("be.visible");
        cy.contains("My plan").should("be.visible");
 
}

   checkOrganizationTabs() {

      cy.get('[aria-label="organization-tabs"]').find('[tabindex="0"]').contains("General").should("be.visible");  
      cy.get('[aria-label="organization-tabs"]').find('[tabindex="-1"]').contains("Billing details").should("be.visible");
      cy.get('[aria-label="organization-tabs"]').find('[tabindex="-1"]').contains("Payment method").should("be.visible");
   }



   checkGeneralTab() {

      cy.contains("My plan").should("be.visible");
     
   }

   checkGeneralTabDetails() {

      cy.contains("Basic details").should("be.visible");
      cy.get('[class="MuiBox-root css-0"]').contains("Core");
      cy.get('[class="MuiBox-root css-0"]').contains("89€");
      cy.get('[class="MuiBox-root css-0"]').contains("0.10€");
      cy.contains("Auto-renewal on").should("be.visible");
   }


    checkTerminateButton() {

      cy.get('[type="button"]').contains("Terminate plan").should("be.visible");


    }
 
   checkBillingdetailsTab() {

      cy.get('[aria-label="organization-tabs"]').find('[tabindex="-1"]').contains("Billing details").should("be.visible").click();
      cy.contains("First name").should("be.visible");
      cy.contains("Last name").should("be.visible");
   }

   checkPaymentTab() {

      cy.get('[aria-label="organization-tabs"]').find('[tabindex="-1"]').contains("Payment method").should("be.visible").click();
      cy.contains("Manage your payment method").should("be.visible");
      
   }
   
}

export default OrganizationPage ;