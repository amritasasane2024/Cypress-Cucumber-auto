class AddOnsPage {

    checkAddOnsOptions() {

        cy.contains("Marketplace").should("be.visible");
        cy.contains("Manage Subscriptions").should("be.visible");
        cy.contains("Direct Flow").should("be.visible");
        


}


    clickMarketPlace() {

        cy.contains("Marketplace").should("be.visible").click({force: true});

}

    checkDirectFlow() {

        cy.get('#direct-flow').contains("Direct Flow").should("be.visible");

}

    clickManageSubscriptions() {

        cy.contains("Manage Subscriptions").should("be.visible").click({force: true});

}

    checkAddOnsDetails() {

        cy.contains("Direct Flow").should("be.visible");
        cy.contains("Created:").should("be.visible");
        cy.contains("Your subscription will").should("be.visible");
}


}
export default AddOnsPage ;