class LoginPage{


     visitUrl(){

        cy.visit('/');
     
    }

     enterEmail(name) {

        cy.get('[id="username"]').type(name);
    }


     enterPassword(password) {

        cy.get('[id="password"]').type(password);
    }

     clickLoginButton() {

        cy.get('[id="kc-login"]').click();
    }

     getGetStartedLink() {
       // cy.contains("ACCEPT ALL").should("be.visible").click();

        cy.contains("Get started").should("be.visible");
    }

    


     checkLoginPage() {

        cy.contains("Welcome back").should("be.visible").click({force:true});
        cy.get('[class="MuiTypography-root MuiTypography-h4 css-1vt5em4"]').contains("New Notifications").type('{esc}')  
       
    }

     checkPlanSelectionMsg() {

        cy.contains("Select plans to get started with Unreal Engine pixel streaming using Cloud").should("be.visible");
    }

     checkBanner() {

        cy.contains("NEW UPDATE HAS BEEN RELEASED ! ! !").should("be.visible");
        
      
    }
     closeBanner() {

     
        cy.get('[data-testid="CloseIcon"]').click({force:true});
    }

    

     checkAndCloseCookiesMsg() {

       // cy.get('.login-pf').should('exist')

        if (cy.contains("Your Privacy"))
        {
      
        cy.get('[id="cookiescript_accept"]').focus().click({force:true});
        }
        else
        {

        cy.log("no cookies found")

        }
      } 
}

//const LoginPage = new loginPage();
export default LoginPage;