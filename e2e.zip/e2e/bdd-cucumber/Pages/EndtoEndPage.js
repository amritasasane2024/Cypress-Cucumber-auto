class EndtoEndPage{


    static enterEmail(name) {

        cy.get('[id="username"]').type(name)
    }


    static enterPassword(password) {

        cy.get('[id="password"]').type(password)
    }

    static clickLoginButton() {

        cy.get('[id="kc-login"]').click();
    }

    static getGetStartedLink() {

        cy.contains("Get started").should("be.visible");
    }


    static checkLoginPage() {

        cy.contains("Welcome back,").should("be.visible");
    }

}

//const LoginPage = new loginPage();
export default EndtoEndPage;