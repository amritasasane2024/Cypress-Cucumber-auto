
class SettingsPage {

 checkSettingsPage() {

   //cy.contains("Project").click({force:true});   
   cy.contains("An enabled project will be available for streaming based on the following settings.").should("be.visible");
    
    cy.get('[aria-label="basic tabs example"]').find('[tabindex="0"]').contains("General").should("be.visible");
    cy.get('[aria-label="basic tabs example"]').find('[tabindex="-1"]').contains("Stream").should("be.visible");
    cy.get('[aria-label="basic tabs example"]').find('[tabindex="-1"]').contains("WebSdk").should("be.visible");
  

}

 checkGeneralTab() {

    cy.contains("General").should("be.visible");
}

 
checkGeneralSettings() {

   cy.contains("Project name").should("be.visible");
   cy.contains("Unreal Engine Version").should("be.visible");
   cy.contains("Width").should("be.visible");
   cy.get('[name="settings.width"][value="1920"]').should("be.visible");
   cy.contains("Height").should("be.visible");
   cy.get('[name="settings.height"][value="1080"]').should("be.visible");
   
}


 
checkGeneralAddSettings() {

   cy.contains("Interacting with the stream").should("be.visible");
   cy.contains("Stream UI").should("be.visible");
}

 clickStreamTab() {

    //cy.contains("Stream").should("be.visible").click();
    cy.get('[aria-label="basic tabs example"]').find('[tabindex="-1"]').contains("Stream").should("be.visible").click()
}

 checkStreamSettings() {

    cy.contains("STREAM SETTINGS").should("be.visible");
    cy.contains("Maximum streams").should("be.visible");
}

clickWebSdkTab() {

   //cy.contains("Stream").should("be.visible").click();
   cy.get('[aria-label="basic tabs example"]').find('[tabindex="-1"]').contains("WebSdk").should("be.visible").click()
}

checkWebSdkSettings() {

   cy.contains("WebSdk Settings").should("be.visible");
   cy.contains("WebSdk InitialSettings").should("be.visible");
}
}

export default SettingsPage ;