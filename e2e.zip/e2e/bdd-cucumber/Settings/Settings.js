import {Given, When, Then} from "@badeball/cypress-cucumber-preprocessor";
import LoginPage from "../Pages/LoginPage";
import LoginConfig from "../Login/LoginConfig";
import UploadConfig from "../Upload/UploadConfig";
import ProjectsPage from "../Pages/ProjectsPage";
import SettingsPage from "../Pages/SettingsPage";
import DashboardPage from "../Pages/DashboardPage";

Cypress.config('baseUrl')

const LoginPageObj = new LoginPage();
const ProjectsPageObj = new ProjectsPage();
const DashboardPageObj = new DashboardPage();
const SettingsPageObj = new SettingsPage(); 

const useremail = LoginConfig.useremail;
const password = LoginConfig.password;
const projName = UploadConfig.projName;
//const shareID = UploadConfig.shareID; 

//Scenario  - Login as user with correct credentials
Given("I launch the Arcware website", () => {

    LoginPageObj.visitUrl();
 //   LoginPageObj.checkCookies();
  //  LoginPageObj.closeCookiesMsg();

})

When("I enter my credentials",  ()  => {   
  
    LoginPageObj.enterEmail(useremail);
    LoginPageObj.enterPassword(password);  
        
})


When("I click on Login",  ()  => {   
  
    LoginPageObj.clickLoginButton(); 
    
    
})

Then("I should be logged into Arcware application", () => {
    
    LoginPageObj.checkLoginPage();
})


// Scenario 2 -  Select desired Project 


Given("I land on the Projects page",  ()  => {   
  
    DashboardPageObj.checkProjects();
    DashboardPageObj.clickProjectsTab();
})

When("I select a particular project",  ()  => {   
  
    ProjectsPageObj.selectProject(projName);
    
        
})

Then("I should be able to view project details", () => {
    
    ProjectsPageObj.checkProjectDetails(projName);
})


// Scenario -  Navigate to Settings

Given("I am able to view Settings option",  ()  => {   
    
  //  LoginPageObj.closeCookiesMsg();
 // ProjectsPageObj.closeSettingsMsg();
    ProjectsPageObj.checkSettingsTab();
   
            
})
 
When("I click on the Settings Link",  ()  => {   
  
    ProjectsPageObj.clickSettingsTab();
        
})

Then("I should be able to navigate to Settings page", () => {
    
    SettingsPageObj.checkSettingsPage();
})


// Scenario -  General and Stream tabs


Given("I am on Settings page",  ()  => {   
  
    SettingsPageObj.checkSettingsPage();
        
})

When("I check General tab",  ()  => {   
  
    SettingsPageObj.checkGeneralTab();
        
})

Then("I should see relevant General settings", () => {
    
    SettingsPageObj.checkGeneralSettings();
    SettingsPageObj.checkGeneralAddSettings();
})

When("I click on Stream tab",  ()  => {   
  
    SettingsPageObj.clickStreamTab();
        
})

Then("I should see Stream settings", () => {
    
    SettingsPageObj.checkStreamSettings();
})


// Scenario: Check WebSdk tab

Given("I have checked Stream tab",  ()  => {   
  
    SettingsPageObj.checkStreamSettings();
        
})

When ("I click on the WebSdk tab",  ()  => {   
  
    SettingsPageObj.clickWebSdkTab();
    
})

Then("I should be able to view WebSdk settings", () => {
    
    SettingsPageObj.checkWebSdkSettings();
})

