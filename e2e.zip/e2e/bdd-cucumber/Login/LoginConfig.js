class configLogin{

 // stormblast
  //      static useremail = "amritasasane@gmail.com";
  //      static password = "Test@12345" ;
//const projName = "testqa" ;
   
    
// prod
       


}
export default configLogin;