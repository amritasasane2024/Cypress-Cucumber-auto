import {Given, When, Then, And} from "@badeball/cypress-cucumber-preprocessor";
//import LoginPage from "./loginPage";
import LoginPage from "../Pages/LoginPage";
import LoginConfig from "./LoginConfig";





Cypress.config('baseUrl')
Cypress.config('viewportWidth', 2000);
Cypress.config('viewportHeight', 1050);

const useremail = LoginConfig.useremail;
const password = LoginConfig.password;


const LoginPageObj = new LoginPage();

//Scenario 1 - Login to application
Given("I navigate to Arcware website", () => {

    LoginPageObj.visitUrl();
   // LoginPageObj.checkCookies();
   // LoginPageObj.closeCookiesMsg();

})

When("I login with my userid and password",  ()  => {   
  
    
    LoginPageObj.enterEmail(useremail);
    LoginPageObj.enterPassword(password);  
    LoginPageObj.clickLoginButton();
   
    
})

Then("I should be logged in", () => {
    
    
    LoginPageObj.closeBanner();
    LoginPageObj.checkLoginPage();
    

})



    

