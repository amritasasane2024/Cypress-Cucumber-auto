import {Given, When, Then, And} from "@badeball/cypress-cucumber-preprocessor";
import RegisterUserPage from "../Pages/RegisterUserPage";
import LoginPage from "../Pages/LoginPage";
import RegisterConfig from "../Register/RegisterConfig.js";
import UploadPackagePage from "../Pages/UploadPackagePage";
import ProjectsPage from "../Pages/ProjectsPage";
import EndtoEndPage from "../Pages/EndtoEndPage";
//import ShareIDPage from "../Pages/ShareIDPage";
import UploadConfig from "../Upload/UploadConfig";
import DashboardPage from "../Pages/DashboardPage";
import StreamingPage from "../Pages/StreamingPage";
import OrganizationPage from "../Pages/OrganizationPage";

Cypress.config('baseUrl')


const firstName = RegisterConfig.firstName;
const lastName = RegisterConfig.lastName;
const email = RegisterConfig.email;
const passwordreg = RegisterConfig.password;
const confPassword = RegisterConfig.confPassword;
const industry = RegisterConfig.industry;
const company = RegisterConfig.company;
const companySize = RegisterConfig.companySize;
const job = RegisterConfig.job;
const countryCode = RegisterConfig.countryCode;
const city = RegisterConfig.city;
const findUs = RegisterConfig.findUs;
const phone = RegisterConfig.phone;
const projName = UploadConfig.projName;

const StreamingPageObj = new StreamingPage();
const LoginPageObj = new LoginPage();
const RegisterUserPageObj = new RegisterUserPage();
const UploadPackagePageObj = new UploadPackagePage();
const DashboardPageObj = new DashboardPage();
const ProjectsPageObj = new ProjectsPage();
const OrganizationPageObj = new OrganizationPage();


//Scenario 1 - Check Registration page available
Given("I launch the Arcware application url", () => {

    LoginPageObj.visitUrl();
 //   LoginPageObj.checkAndCloseCookiesMsg();
})

When("I click on 'Create Account' button", () => {

    RegisterUserPageObj.clickCreateUser();
})

Then("I should be navigated to the Registration page", () => {

    RegisterUserPageObj.getRegisterPage();
    RegisterUserPageObj.getRegisterPageLinks();
})


// Scenario: Verify new user can register 

Given("I land on the Registration page", () => {

    RegisterUserPageObj.getRegisterPage();
})

When("I enter all the required details", () => {

    RegisterUserPageObj.enterBasicFields(firstName, lastName, email, passwordreg, confPassword) ;
    RegisterUserPageObj.enterAdditionalFields(industry, company, companySize, job, countryCode, city, findUs, phone );

})

When("I click on 'Register' button", () => {

    RegisterUserPageObj.clickCheckBoxes();
 //  RegisterUserPageObj.checkTermsCond();
    RegisterUserPageObj.clickRegister();
})

Then ("relevant successful message should be displayed", () => {

    RegisterUserPageObj.getRegisterConfirmation();
})


// Scenario: View Projects

Given("I can see 'Projects' tab", () => {

    DashboardPageObj.checkProjects();
 //   LoginPageObj.checkAndCloseCookiesMsg();
})


When("I click to view the Projects",  () => {   
  
    DashboardPageObj.clickProjectsTab();
})


Then("it should list all Projects", () => {
   
    DashboardPageObj.checkProjectList(projName);
})


//Scenario: Select Project

Given("I can see all the Projects", () => {

    DashboardPageObj.checkProjectList(projName);
 //   LoginPageObj.checkAndCloseCookiesMsg();
})



When("I click to select the desired project",  () => {   
  
    ProjectsPageObj.selectProject(projName);
})


Then("I should be displayed with project details", () => {
   
    ProjectsPageObj.checkProjectDetails(projName);
})


// Scenario: Check Project Plan

 Given("that Project plan option is available under projects", () => {

    ProjectsPageObj.navigateProject(projName);
    ProjectsPageObj.checkProjectPlanTab();
})

When("I click on the Project plan",  () => {   
  
    ProjectsPageObj.clickProjectPlanTab();
})

Then("I should be able to view Plan details", () => {
   
    ProjectsPageObj.checkProjectPlanDetails(projName);
})


// Scenario: View Organization tab

Given("I see the Organization tab on left", () => {

    DashboardPageObj.checkOrganizationTab();
 //   LoginPageObj.checkAndCloseCookiesMsg();
})



When("I click the Organization tab",  ()  => {   
  
    DashboardPageObj.clickOrganizationTab();
})


Then("I should be taken to the relevant page", () => {
   
    OrganizationPageObj.checkOrganizationPage();
})


//Scenario: View Organization page details General tab


Given("I am on the Organization page", () => {

    OrganizationPageObj.checkOrganizationPage();
})


When("I check for the General tab",  ()  => {   
  
    OrganizationPageObj.checkOrganizationTabs();
    OrganizationPageObj.checkGeneralTab()
})


Then("I should be able to see all relevant details", () => {
   
    OrganizationPageObj.checkGeneralTabDetails();
    OrganizationPageObj.checkTerminateButton();
   
})

 
//Scenario: View Organization page details other tabs


Given("I am on the General tab page", () => {

    OrganizationPageObj.checkGeneralTab();
   
})


When("I check for the other tabs",  ()  => {   
  
    OrganizationPageObj.checkOrganizationTabs();
    
})


Then("I should be able to see all relevant tab details", () => {
   
   // OrganizationPageObj.checkGeneralTab();
    OrganizationPageObj.checkBillingdetailsTab();
    OrganizationPageObj.checkPaymentTab();

})


// Scenario: Create new project

Given("I am on the Projects tab", () => {

    DashboardPageObj.checkProjects();
   
})


When("I click on 'Create new Project' link", () => {

    ProjectsPageObj.clickNewProjectLink();
   
})


When("I enter required information and submit", () => {

    ProjectsPageObj.enterProjectInfo();
    ProjectsPageObj.clickCreateProjectButton();
   
})


Then("new project is created", () => {

    ProjectsPageObj.checkCreatedMsg();
   
})


