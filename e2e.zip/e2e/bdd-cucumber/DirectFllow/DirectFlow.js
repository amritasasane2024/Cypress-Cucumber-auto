import {Given, When, Then} from "@badeball/cypress-cucumber-preprocessor";
import LoginPage from "../Pages/LoginPage";
import LoginConfig from "../Login/LoginConfig";
import UploadConfig from "../Upload/UploadConfig";
import ProjectsPage from "../Pages/ProjectsPage";
import DashboardPage from "../Pages/DashboardPage";
import AddOnsPage from "../Pages/AddOnsPage";


//const StreamingPageObj = new StreamingPage();
const LoginPageObj = new LoginPage();
//const RegisterUserPageObj = new RegisterUserPage();
//const UploadPackagePageObj = new UploadPackagePage();
const DashboardPageObj = new DashboardPage();
const AddOnsPageObj = new AddOnsPage();
 

Given("that I am able to view the Add ons option", () => {

    DashboardPageObj.checkAddOnsTab();
})

When("I click on the Add ons tab", () => {

    DashboardPageObj.clickAddOnsTab();
})

Then ("it should display sub menu items", () => {

    AddOnsPageObj.checkAddOnsOptions();
 
})


//Scenario: Check for Direct Flow option

Given ("that I am able to view the Marketplace option" , () => {

    AddOnsPageObj.checkAddOnsOptions();
 
})


When ("I click on the Marketplace option" , () => {

    AddOnsPageObj.clickMarketPlace();
 
})


Then ("it should display Direct Flow option" , () => {

    AddOnsPageObj.checkDirectFlow();
 
})


// Scenario: Check for Manage Subscriptions option

Given ("that I am able to view options under Add Ons" , () => {

    AddOnsPageObj.checkAddOnsOptions();
 
})

  
When ("I click on the Manage Subscriptions option" , () => {

    AddOnsPageObj.clickManageSubscriptions();
 
})

 
Then ("it should display all the Add Ons and details" , () => {

    AddOnsPageObj.checkAddOnsDetails();
 
})