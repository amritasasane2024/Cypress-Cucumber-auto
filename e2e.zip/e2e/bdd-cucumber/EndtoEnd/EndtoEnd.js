import {Given, When, Then} from "@badeball/cypress-cucumber-preprocessor";
//import LoginPage from "./loginPage";
import LoginPage from "../Pages/LoginPage";
import LoginConfig from "../Login/LoginConfig";
//import CreateTenantPage from "../Pages/createTenantPage";
import UploadPackagePage from "../Pages/UploadPackagePage";
import ProjectsPage from "../Pages/ProjectsPage";
import EndtoEndPage from "../Pages/EndtoEndPage";
//import ShareIDPage from "../Pages/ShareIDPage";
import UploadConfig from "../Upload/UploadConfig";
import DashboardPage from "../Pages/DashboardPage";
import StreamingPage from "../Pages/StreamingPage";



Cypress.config('baseUrl')
const useremail = LoginConfig.useremail;
const password = LoginConfig.password;
const projName = UploadConfig.projName;
const upFile = UploadConfig.upTemplate; 
//const shareID = UploadConfig.shareID; 

const DashboardPageObj = new DashboardPage();
const StreamingPageObj = new StreamingPage();
const LoginPageObj = new LoginPage();
const ProjectsPageObj = new ProjectsPage();
const UploadPackagePageObj = new UploadPackagePage();


//Scenario 1 - Login to application
Given("I load the Arcware website", () => {

    LoginPageObj.visitUrl();
 //   LoginPageObj.checkAndCloseCookiesMsg();
})

When("I enter my userid and password",  ()  => {   
  
    LoginPageObj.enterEmail(useremail);
    LoginPageObj.enterPassword(password);  
    
    
})

When("I click on Login button" , () => {
    
    LoginPageObj.clickLoginButton();

})

Then("I should be logged into application", () => {
    
   
    //LoginPage.getGetStartedLink();
    LoginPageObj.checkLoginPage();
    
  })


//Scenario 2 - Check and close the Banner
Given("I am logged into Arcware", () => {

    LoginPageObj.checkLoginPage();
    
    
})

When("the Banner is displayed", () => {

   // LoginPage.checkBanner();
    
})

Then("I should be able to close it",  ()  => {   

    //LoginPage.closeBanner();

})



//Scenario  - Get Started link 
/*
Given("I am on Arcware Logged in page", () => {

    LoginPageObj.checkLoginPage();
    
})

When("I check for the 'Get Started' link",  ()  => {   

   
    LoginPageObj.getGetStartedLink();
    
  
})

Then("I should be able to click the link", () => {
    
    EndtoEndPage.clickGetStarted();
 
 })

*/

//Scenario - Display available plans
Given("I have clicked the 'Get Started' link", () => {

    LoginPageObj.getGetStartedLink();
    
})

When("I am navigated to the Plan selection page",  ()  => {   

   
    EndtoEndPage.checkPlanSelectionMsg();
      
})

Then("I should be able to see all available plans", () => {
    
    CreateTenantPage.checkPlansAvailable();
 
 })


//Scenario -  Select Trial plan
Given("I can view available plans", () => {

    CreateTenantPage.checkPlansAvailable();
    
})

When("I click to select Trial plan",  ()  => {   

   
    CreateTenantPage.selectTrialPlan();
      
})

Then("the Trial plan should be selected", () => {
    
    CreateTenantPage.checkTrialPlan();
 
 })

 //Scenario  - View Projects
Given("I can view 'Projects' tab", () => {

    DashboardPageObj.checkProjects();

})

When("I click to navigate to the Projects",  ()  => {   
  
    DashboardPageObj.clickProjectsTab();
})


Then("it should display all projects", () => {
   
    DashboardPageObj.checkProjects();
})


//Scenario  - Select Project
Given("I can view all the Projects", () => {

    ProjectsPageObj.checkProjectsPage();

})

When("I click to select a particular project",  ()  => {   
  
    ProjectsPageObj.selectProject(projName);
})


Then("I should be navigated to project details", () => {
   
    ProjectsPageObj.checkProjectDetails(projName);
})


// Scenario - Select package to upload

Given("I am on the Packages tab", () => {

    ProjectsPageObj.clickPackagesTab();

})

When("I click on the 'Browse your package' option",  ()  => {   
  
   // UploadPackagePageObj.clickBrosweOption();
})


Then("I should be able to add package for upload", () => {
   
    UploadPackagePageObj.selectPackage(upFile);
})


// Scenario  -  Perform release to cloud  

Given("I click on the Package tab from the Project", () => {

  
    ProjectsPageObj.checkPackagesTab();
    ProjectsPageObj.clickPackagesTab();
    
})

When("I click on the release button",  ()  => {   

    UploadPackagePageObj.clickReleaseButton();
    UploadPackagePageObj.clickConfirmRelease();
  
})

Then("I should be able to see the status", () => {
 
    UploadPackagePageObj.checkReleaseStatus();

})


//Scenario: Check Auto Release option

Given("I can see the Auto Release option", () => {

  
    UploadPackagePageObj.checkAutoReleaseOption();


})

 When("I click on the toggle button", () => {
 
    UploadPackagePageObj.clickAutoReleaseButton();

})

Then("I should be able to turn on or off the option", () => {
 
    UploadPackagePageObj.checkAutoReleaseButtonMsg();

})




//Scenario  -  Check Active state for package
 
Given("I am viewing status on the Packages", () => {

   
    UploadPackagePageObj.checkReleaseStatus();

    
})

When("I view the statuses for Release",  ()  => {   

    UploadPackagePageObj.checkRelevantStatus();
  
})

Then("I should be able to see the final Active status", () => {
 
    UploadPackagePageObj.checkFinalStatus();

})

//Scenario  - Explore streaming
    Given("I can see Preview option in the Project", () => {

        ProjectsPageObj.navigateProject(projName);
        ProjectsPageObj.checkPreviewTab();
       
   })
   
   When("I click on the Preview tab",  ()  => {   
   
        ProjectsPageObj.clickPreviewTab();
     
   })
   
   Then("it should display streaming image", () => {
    
        StreamingPageObj.checkStreamingVideo();
   
   })


   // Scenario 8 -   Check Share ID
  

    Given("I can see the Share ID option in the Project", () => {

        ProjectsPageObj.navigateProject(projName);
        ProjectsPageObj.checkShareIDTab();
       
   })

    When("I click on the Share ID tab",  ()  => {   
   
        ProjectsPageObj.clickShareIDTab();
  
})

    Then("I should be navigated to the Share ID page", () => {
    
        ProjectsPageObj.checkShareIDPage();

})


 // Scenario 9- Create a new share id
    
    Given("I click on the Create Share ID link", () => {

        
        ShareIDPage.clickCreateShareIDLink();
       
   })

 
    When("I enter all details",  ()  => {   
   
        ShareIDPage.enterShareIDDetails(projName,shareID);

})
    
    When("I submit all information",  ()  => {   
   
        ShareIDPage.submitShareID();

})
     
    Then("a new Share ID should be created", () => {
    
        ShareIDPage.checkCreatedShareID(shareID);

})

// Scenario 10 -  Check details of Share ID
     
    Given("I have created a new Share ID", () => {

        
        ShareIDPage.checkCreatedShareID(shareID);
   
})
 
    When("I check the list",  ()  => {   
   
        ShareIDPage.checkListShareIds(shareID);

})
 
  
    Then("I should be able to see relevant information", () => {
    
        ShareIDPage.checkShareIdDetails(shareID);
        const shareIDGen = ShareIDPage.getGeneratedShareID();

})


// Scenario 11 -  Copy link for Share ID
 
    Given("that Copy Share Link is available", () => {

        
        ShareIDPage.checkCopyLink();

})

    When("I click on the Copy link",  ()  => {   
   
        ShareIDPage.clickCopyLink();

})

    Then("the link should get copied successfully", () => {
    
        ShareIDPage.checkCopiedMsg();

})

//Scenario 12 -  Check streaming in browser
    Given ("that shared link is copied in clipboard", () => {

    ShareIDPage.clickCopyLink();

})
    When ("I paste the link in browser" , () => {

    ShareIDPage.clickPasteLink();

})

    Then ("I should be able to see streaming", () => {


} )
