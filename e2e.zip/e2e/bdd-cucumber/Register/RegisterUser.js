import {Given, When, Then, And} from "@badeball/cypress-cucumber-preprocessor";
import RegisterUserPage from "../Pages/RegisterUserPage";
import LoginPage from "../Pages/LoginPage";
import RegisterConfig from "./RegisterConfig";


const firstName = RegisterConfig.firstName;
const lastName = RegisterConfig.lastName;
const email = RegisterConfig.email;
const password = RegisterConfig.password;
const confPassword = RegisterConfig.confPassword;
const industry = RegisterConfig.industry;
const company = RegisterConfig.company;
const companySize = RegisterConfig.companySize;
const job = RegisterConfig.job;
const countryCode = RegisterConfig.countryCode;
const city = RegisterConfig.city;
const findUs = RegisterConfig.findUs;
const phone = RegisterConfig.phone;

Cypress.config('baseUrl')

const LoginPageObj = new LoginPage();
const RegisterUserPageObj = new RegisterUserPage();

//Scenario 1 - Check for Register page
Given("I navigate to Arcware application", () => {

   
    LoginPageObj.visitUrl();
   

})

When("I click on 'Create Account' link",  ()  => {   
  
  
    RegisterUserPageObj.clickCreateUser();
    
})

Then("I should be displayed with register page", () => {
    
    RegisterUserPageObj.getRegisterPage();
    RegisterUserPageObj.getRegisterPageLinks();

})


//Scenario 2 - Enter basic information
Given("I am navigated to the Register page", () => {

    RegisterUserPageObj.getRegisterPage();

})

When("I click on different available fields",  ()  => {   
  
  
    RegisterUserPageObj.clickBasicFields();
    
})

Then("I should be able to enter input", () => {
    
    RegisterUserPageObj.enterBasicFields(firstName, lastName, email, password, confPassword);
})


//Scenario 3 - Enter Additional information
Given("I am on Additonal Information section on the Register page", () => {

    RegisterUserPageObj.getAddInfo();

})

When("I click on additonal available fields",  ()  => {   
  
  
    RegisterUserPageObj.clickAdditionalFields();
    
})

Then("I should be able to enter and select all input", () => {
    
    RegisterUserPageObj.enterAdditionalFields(industry, company, companySize, job, countryCode, city, findUs, phone );
    RegisterUserPageObj.clickCheckBoxes();
    
})


//Scenario 4 -  Submit information using Register
Given("I have accepted the 'Terms and Conditions'", () => {

    RegisterUserPageObj.checkTermsCond();

})

When("I click on Register link",  ()  => {   
  
  
    RegisterUserPageObj.clickRegister();
    
})

Then("I should be able to get confirmation message", () => {
    
    
    RegisterUserPageObj.getRegisterConfirmation();
    
})
