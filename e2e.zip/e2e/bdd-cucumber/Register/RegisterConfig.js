class RegisterConfig{

    
        static firstName = "Amrita";
        static lastName = "Sasane" ;
        static email = "amritasasane123@gmail.com";
        static password = "Test123" ;
        static confPassword = "Test123" ;
        static industry = "Media";
        static company = "xyz";
        static companySize = "51 to 200 Employees";
        static job = "Engineer";
        static countryCode = "Germany";
        static city = "Munich";
        static findUs = "LinkedIn Post";
        static phone = "12345";
//const projName = "testqa" ;
   

}
export default RegisterConfig;