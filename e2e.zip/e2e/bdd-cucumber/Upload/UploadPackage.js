import {Given, When, Then} from "@badeball/cypress-cucumber-preprocessor";
import UploadPackagePage from "../Pages/UploadPackagePage";


const fileUp = 'SmallTestFile.zip';
const filepath = 'D:\Testing\SmallTestFile.zip' ;
const projName = 'QA_Project_11.09';






//Scenario 2 - View Projects
Given("'Projects' tab is available", () => {

    UploadPackagePage.checkProjectsTab();

})

When("I click on the Projects tab",  ()  => {   
  
    UploadPackagePage.clickProjectsTab();
})


Then("it should display available projects", () => {
   
    UploadPackagePage.checkProjects();
})




//Scenario 3 - Select Project
Given("I can view all Projects", () => {

    UploadPackagePage.checkProjectsTab();

})

When("I click on a particular project",  ()  => {   
  
    UploadPackagePage.selectProject(projName);
})


Then("I should be navigated to the project page", () => {
   
    UploadPackagePage.checkProjectDetails(projName);
})



//Scenario 4 - Select package to upload

Given("I am visit the Packages tab", () => {

    UploadPackagePage.checkPackagesTab();
    
})

When("I click on the 'Browse your package' link",  ()  => {   
  
    UploadPackagePage.clickBrosweOption();
})


Then("I should be able to add packages", () => {
    
    UploadPackagePage.selectPackage(fileUp);
})


