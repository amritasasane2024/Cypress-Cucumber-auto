class UploadConfig{

   // Select projects

   static projName = "QA_Project_Last 29.02" ;
   //static projName = "QA_Project_03.11" ;
   // static projName = "Test2";
    static projName = "QA_Project";

   // for create sahare id
   static shareID = "Shareid test"; 
   static envUrl = "stormblast.arcware.cloud" ;


    // upload packages
    static upTemplate = 'img3.zip'
    // static upTemplate = 'SmallTest.zip'
    

}
export default UploadConfig;