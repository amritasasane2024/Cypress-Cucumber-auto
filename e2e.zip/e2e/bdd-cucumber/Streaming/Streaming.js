import {Given, When, Then} from "@badeball/cypress-cucumber-preprocessor";
import LoginPage from "../Pages/LoginPage";
import LoginConfig from "../Login/LoginConfig";
import UploadPackagePage from "../Pages/UploadPackagePage";
import UploadConfig from "../Upload/UploadConfig";
import ProjectsPage from "../Pages/ProjectsPage";
//import SettingsPage from "../Pages/SettingsPage";
import DashboardPage from "../Pages/DashboardPage";
import StreamingPage from "../Pages/StreamingPage";

Cypress.config('baseUrl')
const DashboardPageObj = new DashboardPage();
const StreamingPageObj = new StreamingPage();
const LoginPageObj = new LoginPage();
const ProjectsPageObj = new ProjectsPage();
const UploadPackagePageObj = new UploadPackagePage();

const useremail = LoginConfig.useremail;
const password = LoginConfig.password;
const projName = UploadConfig.projName;
//const shareID = UploadConfig.shareID; 

//Scenario 1 - Login as user with correct credentials
Given("I launch the Arcware application", () => {

    LoginPageObj.visitUrl();
 //   LoginPageObj.checkAndCloseCookiesMsg();

})


When("I enter valid credentials and login",  ()  => {   
  
    LoginPageObj.enterEmail(useremail);
    LoginPageObj.enterPassword(password);  
    LoginPageObj.clickLoginButton(); 
})

Then("I should be logged into Arcware website", () => {
    
    LoginPageObj.checkLoginPage();
})


// Scenario 2 -  Select desired Project 


Given("I am on the Projects page",  ()  => {   
  
    DashboardPageObj.checkProjects();
    DashboardPageObj.clickProjectsTab();
        
})

When("I click a particular project",  ()  => {   
  
    ProjectsPageObj.selectProject(projName);
        
})

Then("I should be able to see project details", () => {
    
    ProjectsPageObj.checkProjectDetails(projName);
})


// Scenario 3 -  Navigate to Packages
 

Given("I am able to view Packages option",  ()  => {   
  
    ProjectsPageObj.checkPackagesTab();
        
})

When("I click on the Packages Link",  ()  => {   
  
    ProjectsPageObj.clickPackagesTab();
        
})

Then("I should be able to navigate to Packages page", () => {
    
    UploadPackagePageObj.checkPackagesPage();
})

// Scenario -  Perform release to cloud  


Given("I am on Packages tab", () => {

  
    ProjectsPageObj.clickPackagesTab();
    
})

When("I press the release button",  ()  => {   

    
    UploadPackagePageObj.clickReleaseButton();
    UploadPackagePageObj.clickConfirmRelease();
  
})

Then("I should be able to see the status update", () => {
 
    UploadPackagePageObj.checkReleaseStatus();
    UploadPackagePageObj.checkFinalStatus();

})


//Scenario  - Explore streaming
Given("Preview option is available in the Project", () => {

    ProjectsPageObj.navigateProject(projName);
    ProjectsPageObj.checkPreviewTab();
   
})

When("I click on the Preview option",  ()  => {   

   // LoginPageObj.checkAndCloseCookiesMsg();
    ProjectsPageObj.clickPreviewTab();
 
})

Then("it should display streaming video", () => {

   StreamingPageObj.checkStreamingVideo();
   StreamingPageObj.checkStreamParameters();
   StreamingPageObj.checkLatencyParam();
  
})