import {Given, When, Then} from "@badeball/cypress-cucumber-preprocessor";
import LoginPage from "../Pages/LoginPage";
import ShareIDPage from "../Pages/ShareIDPage";
//import UploadPackagePage from "../Pages/UploadPackagePage";
import LoginConfig from "../Login/LoginConfig";
import UploadConfig from "../Upload/UploadConfig";
import ProjectsPage from "../Pages/ProjectsPage";
import StreamingPage from "../Pages/StreamingPage";


Cypress.config('baseUrl')
const ShareIDPageObj = new ShareIDPage();
const StreamingPageObj = new StreamingPage();
const LoginPageObj = new LoginPage();
const ProjectsPageObj = new ProjectsPage();

const useremail = LoginConfig.useremail;
const password = LoginConfig.password;
const projName = UploadConfig.projName;
const shareID = UploadConfig.shareID; 
const envUrl = UploadConfig.envUrl ;


//Scenario - Login
Given("I navigate to the Arcware website", () => {

    LoginPageObj.visitUrl();
 //   LoginPageObj.checkAndCloseCookiesMsg();

})

When("I login with userid and password", () => {

    LoginPageObj.enterEmail(useremail);
    LoginPageObj.enterPassword(password);  
    LoginPageObj.clickLoginButton();

})

Then("I should be logged into Arcware", () => {
    
 //   LoginPageObj.checkAndCloseCookiesMsg();
    LoginPageObj.checkLoginPage();
})




// Scenario - Check Share ID page

  
Given("I can see the Share ID option", () => {

 //  ProjectsPage.navigateProject(projName);
    ProjectsPageObj.checkShareIDTab();
 
 
 })
 
When ("I click on the Share ID link", () => {

    ProjectsPageObj.clickShareIDTab();
   
   
   })
   
   
Then("I should be navigated to the Share ID details", () => {

    ProjectsPageObj.checkShareIDPage();
   
   
   }) 


// Scenario -  Create a new share id

   
Given("I click on the Create Share ID option", () => {

        
    ShareIDPageObj.clickCreateShareIDLink();
   
})


When("I enter all required details",  ()  => {   

    ShareIDPageObj.enterShareIDDetails(projName,shareID);

})

When("I submit all the information",  ()  => {   

    ShareIDPageObj.submitShareID();

})
 
Then("a new Share ID should be generated", () => {

    ShareIDPageObj.checkCreatedShareID(shareID);

})


// Scenario-  Check Copy link for Share ID

Given("that Copy Share Link is present", () => {

        
    ShareIDPageObj.checkCopyLink();

})

When("I click on the Copy link option",  ()  => {   

    ShareIDPageObj.clickCopyLink();

})

Then("the link should get copied", () => {

    ShareIDPageObj.checkCopiedMsg();
   
})


//Scenario-  Check streaming in browser
Given ("that shared id is available", () => {

    ShareIDPageObj.checkShareIdDetails(shareID);

})
When ("I paste the shareid link in browser" , () => {

    const myShareid = ShareIDPageObj.getGeneratedShareID(envUrl)
  
   // ShareIDPageObj.createShareIDlink(myShareid);
})

Then ("I should be able to stream", () => {

    StreamingPageObj.checkStreamingVideo();
  

} )